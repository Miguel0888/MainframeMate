# Extracted video recording subproject

Dieses Paket wurde aus dem Archiv `WD4J-main(9).zip` herausgelöst und als eigenständiges Gradle-Subproject vorbereitet.

## Ziel
- Videofunktion möglichst vollständig extrahieren
- Originaldateien so wenig wie möglich verändern
- App- und Playwright-Adapter-Dateien getrennt nach Herkunft ablegen

## Struktur
- `app-src/main/java`: Dateien aus `app/src/main/java`
- `playwright-adapter-src/main/java`: Dateien aus `playwright-adapter/src/main/java`
- `app-src/main/resources`: relevante App-Ressourcen
- `wd4j-src/main/resources`: `scripts/recorder.js`

## Hinweis zum Build
Die Dateien wurden weitgehend unverändert übernommen. Das Paket ist als Subproject vorbereitet, kann aber wegen weiterer Projektabhängigkeiten aus dem Ursprungsrepo (`:playwright-java`, `:wd4j` und zusätzliche App-Klassen) noch Integrationsarbeit benötigen.

## Enthaltene Dateien
Insgesamt: 79 Dateien

